/* Dado el siguiente Array, informar por pantalla todos los valores en posiciones impares. */

var animales = ['Perro','Gato','Ratón','Loro','Aguila','Ballena','Tiburón','Oso'];