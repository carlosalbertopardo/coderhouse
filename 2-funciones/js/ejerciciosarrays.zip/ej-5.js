/* Realizar un programa en el cual se ingresen los nombres de los alumnos de la clase con la funcion "prompt". 
Para detener la carga de datos, usar la función "confirm".
Una vez terminada la carga de dato, analizarlos de la siguiente forma:
- En el caso de que la cantidad de alumnos ingresados sea la de la totalidad de los alumnos de la clase, indicar con un alert que todos los alumnos
están presentes.
- En el caso de que la cantidad de alumnos ingresados sea menor a la de la totalidad de los alumnos de la clase, indicar con un alert que no están todos presentes y cuantas personas faltan.
- En el caso de que la cantidad de alumnos ingresados sea mayor a la de la totalidad de los alumnos de la clase, indicar con un alert que hay gente nueva.
*/