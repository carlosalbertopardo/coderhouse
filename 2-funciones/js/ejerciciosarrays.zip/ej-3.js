/* Dado un array, quitar el primer elemento del mismo. */
/* Recordar que los arrays funcionan como una pila. */

var equiposDeFutbol = ['River','Boca','Racing','Independiente','San Lorenzo','Huracán'];