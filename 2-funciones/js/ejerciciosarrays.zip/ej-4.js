/* Dados los siguientes arrays, indicar por pantalla si tienen algún elemento en común */

var apellidos = ["Gonzalez","Pérez","Blanco","Espósito","Martínez"]
var colores = ["Azul","Verde","Amarillo","Blanco","Naranja",]
