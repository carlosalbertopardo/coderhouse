/* Dado el siguiente Array, informar por pantalla si se encontró algun elemento que no sea un string y en que posicion está */

var animales = ['Perro','Gato','Ratón','Loro','Aguila', 45873,'Ballena','Tiburón','Oso'];