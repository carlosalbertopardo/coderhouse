/*  

EJERCICIO N°1
"Crear un objeto llamado canción,
el cual tenga las propiedades id, letra, autor y duración
Luego mostrar los datos por la consola un dato por linea."

*/