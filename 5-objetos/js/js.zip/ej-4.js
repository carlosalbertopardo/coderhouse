/*  

EJERCICIO N°4
"Dado el siguiente objeto, crear sus setters y getters."
-Crear tambíen un método que muestre por pantalla si la persona
puede entrar en una montaña rusa (Altura > 1.5).
*/

var persona = {
	nombre: "Bart",
	apellido: "Simpson",
	edad: 10,
	altura: 1.3,
	colorDePelo: "Rubio"
}
