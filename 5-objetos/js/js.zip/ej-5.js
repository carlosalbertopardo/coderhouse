/*  

EJERCICIO N°5
"Crear un objeto llamado partidoDeFutbol, el cual tenga las propiedades id (numero),
jugadoresEquipo1 (array), jugadoresEquipo2 (array), golesEquipo1 (numero), golesEquipo2 (numero).
- Deberá tener 1 metodo golEquipo1 y otro golEquipo2 que sumará 1 a los goles del equipo especificado.
- Crear otro metodo que muestre por pantalla como salió el partido.
- hacer un metodo para agregar jugadores.

*/